import se.mau.DA343A.VT25.assignment2.Logger;

public class MyLogger extends Logger {

    @Override
    protected void writeMessage(String s) {
        System.out.println(s);
    }
}
