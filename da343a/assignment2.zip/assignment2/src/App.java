import se.mau.DA343A.VT25.assignment2.*;

import java.awt.image.BufferedImage;
import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;

public class App extends GUI implements IPlayPauseButtonPressedCallback {

    private IPlayPauseButtonPressedCallback callback;

    public App(BufferedImage mapImage) {
        super(mapImage);
        addPlayPauseButtonCallback(this);
    }

    @Override
    public void addPlayPauseButtonCallback(IPlayPauseButtonPressedCallback iPlayPauseButtonPressedCallback) {
        this.callback = iPlayPauseButtonPressedCallback;
    }

    @Override
    public void removePlayPauseButtonCallback(IPlayPauseButtonPressedCallback iPlayPauseButtonPressedCallback) {
        this.callback = null;
    }

    @Override
    protected void invokePlayPauseButtonCallbacks() {

    }

    @Override
    protected void onExiting() {
    }

    @Override
    public void playPauseButtonPressed() {
    }

}
