/*
 * motor.h
 *
 * Created: 2025-01-08 15:10:37
 *  Author: aq3915
 */ 


#ifndef MOTOR_H_
#define MOTOR_H_

void motor_init(void);
void motor_set_speed(uint8_t speed);

#endif /* MOTOR_H_ */